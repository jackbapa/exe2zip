//go:generate goversioninfo -icon=../resource/icon.ico -manifest=../resource/goversioninfo.exe.manifest

package main

import "fmt"

func main() {
	fmt.Println("Hello world")
}
