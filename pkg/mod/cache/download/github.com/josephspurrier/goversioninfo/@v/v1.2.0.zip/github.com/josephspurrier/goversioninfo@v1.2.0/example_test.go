//go:generate goversioninfo -icon=testdata/resource/icon.ico -manifest=testdata/resource/goversioninfo.exe.manifest -64

package goversioninfo_test

import "fmt"

func Example() {
	fmt.Println("Hello world")
}
